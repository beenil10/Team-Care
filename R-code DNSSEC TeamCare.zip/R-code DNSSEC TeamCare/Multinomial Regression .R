library(nnet)
library(coefplot)
library(ggplot2)



colnames(zf_output)[(ncol(zf_output)-1):ncol(zf_output)] <- c("average_outage_in_days", "average_sigval_in_days")

set.seed(123) 
train_indices <- sample(1:nrow(zf_output), 0.8 * nrow(zf_output))
train_data <- zf_output[train_indices, ]
test_data <- zf_output[-train_indices, ]



model2 <- multinom(zone_status ~ avg_ttl + average_sigval_in_days + dnssec_status, data = train_data)


predictions <- predict(model2, newdata = test_data, type = "class")


confusion_matrix <- table(test_data$zone_status, predictions)
print(confusion_matrix)


accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
print(paste("Accuracy:", accuracy))


summary(model2)

#plot
coefficients <- coef(model2)

coefplot(model2)








