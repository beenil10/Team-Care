install.packages("randomForest")
install.packages("caret")

library(randomForest) 
library(caret) 


set.seed(123) 


zf_output$zone_status <- factor(zf_output$zone_status)


trainIndex <- createDataPartition(zf_output$zone_status, p = .8, 
                                  list = FALSE, 
                                  times = 1)
train_data <- zf_output[trainIndex, ]
test_data <- zf_output[-trainIndex, ]


rf_model <- randomForest(zone_status ~ avg_ttl + dnssec_status + average_sigval_in_days, data = train_data)


predictions <- predict(rf_model, test_data)


confusionMatrix(predictions, test_data$zone_status)


importance(rf_model)


varImpPlot(rf_model)









