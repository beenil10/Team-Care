library(ggplot2)


# Create a grouped bar plot for DNSSEC Status impact on Zone Status
ggplot(test_data, aes(x = factor(dnssec_status), fill = factor(zone_status))) +
  geom_bar(position = "dodge", alpha = 0.8) +
  labs(title = "Impact of DNSSEC Status on Zone Status",
       x = "DNSSEC Status",
       y = "Count") +
  scale_x_discrete(labels = c("No DNSSEC", "DNSSEC")) +
  scale_fill_manual(values = c("#1b9e77", "#d95f02", "#7570b3"), 
                    labels = c("No outage", "Complete outage", "Partial outage")) +
  theme_minimal() +
  theme(plot.title = element_text(size = 16, face = "bold"),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        axis.text = element_text(size = 12)) +
  coord_cartesian(ylim = c(0, 200))  
