#Load libraries
library(tidyverse)#Tidyverse and data operations
library(lattice)
library(caret)
library(corrplot)
library(ggcorrplot)
library(rsample)
library(dplyr)

############################# NATURAL DISASTERS ################################

Nat_Dis_in <- read.csv(file = "V2_NatDis.csv")

mydf <- Nat_Dis_in[,c(1:14,23)]


ggcorrplot(corr=cor(mydf), type="lower",
           ggtheme=ggplot2::theme_gray, lab=TRUE,
           title="Correlations for Numeric Variables")


set.seed(1234)

# Splitting of the data
df_split <- initial_split(mydf, prop = 0.7)

# Training dataset
df_train <- df_split %>%
  training()

# Testing / Validation dataset
df_valid <- df_split %>%
  testing()

df_glm <- glm(FINAL_NOT_ONLINE~
                IS_AUTH+
                VALID_SOA+
                KEYS_VERIF,
                data = df_train)

summary(df_glm)

glm.probs <- predict(df_glm, df_valid) 
glm.pred <- rep(0, length(glm.probs)) 
glm.pred[glm.probs>0.5]<- 1

table(glm.pred, df_valid$FINAL_NOT_ONLINE) #473
mean(glm.pred==df_valid$FINAL_NOT_ONLINE)

sensitivity(glm.pred, df_valid$IS_NOT_ONLINE)

############################# EXPIRED SIGNATURES ###############################


SecSpider <- read.csv(file = "query_output.csv")

mydf <- SecSpider[,-c(1)]
mydf <- mydf[,c(1:11,13:15)]

mydf$SIG_OUTAGE <- ifelse(mydf$EXP < mydf$LAST_SEEN, 1,0)

ggcorrplot(corr=cor(mydf), type="lower",
           ggtheme=ggplot2::theme_gray, lab=TRUE,
           title="Correlations for Numeric Variables")

set.seed(1234)

# Splitting of the data
df_split <- initial_split(mydf, prop = 0.7)

# Training dataset
df_train <- df_split %>%
  training()

# Testing / Validation dataset
df_valid <- df_split %>%
  testing()

df_glm <- glm(SIG_OUTAGE~
                LAST_SEEN+
                EXP+
                VALID_SOA+
                KEYS_VERIF,
              data = df_train)

summary(df_glm)

glm.probs <- predict(df_glm, df_valid) 
glm.pred <- rep(0, length(glm.probs)) 
glm.pred[glm.probs>0.5]<- 1

table(glm.pred, df_valid$SIG_OUTAGE) #473
mean(glm.pred==df_valid$SIG_OUTAGE)

specificity(factor(glm.pred),factor(df_valid$SIG_OUTAGE))


############################# OUTAGE as a WHOLE ################################
library(dplyr)

SecSpider <- read.csv(file = "query_output.csv")
SecSpider <- SecSpider[,-c(1)]

Nat_Dis_in <- read.csv(file = "V2_NatDis.csv")
Outages <- bind_rows(Nat_Dis_in,SecSpider)

mydf <- Outages[,c(1:14,23)]

mydf$SIG_OUTAGE <- ifelse(mydf$EXP < mydf$LAST_SEEN, 1,0)

mydf$DURATION_SIG_OUTAGE <- ifelse(mydf$LAST_SEEN - mydf$EXP > 0,
                                   mydf$LAST_SEEN - mydf$EXP,
                                   0)

mydf$OUTAGE <- ifelse(mydf$FINAL_NOT_ONLINE | mydf$SIG_OUTAGE, 1, 0)
mydf$OUTAGE <- ifelse(is.na(mydf$OUTAGE),0,mydf$OUTAGE)



ggcorrplot(corr=cor(mydf), type="lower",
           ggtheme=ggplot2::theme_gray, lab=TRUE,
           title="Correlations for Numeric Variables")

set.seed(1234)

# Splitting of the data
df_split <- initial_split(mydf, prop = 0.7)

# Training dataset
df_train <- df_split %>%
  training()

# Testing / Validation dataset
df_valid <- df_split %>%
  testing()

df_glm <- glm(OUTAGE~
               DURATION_SIG_OUTAGE+
               TTL+
               KEYTAG+
               ALGO+
               IS_AUTH+
               VALID_SOA+
               KEYS_VERIF,
             data = df_train)

summary(df_glm)

glm.probs <- predict(df_glm, df_valid) 
glm.pred <- rep(0, length(glm.probs)) 
glm.pred[glm.probs>0.5]<- 1

table(glm.pred, df_valid$OUTAGE) #473
specificity(factor(glm.pred),factor(df_valid$OUTAGE))
